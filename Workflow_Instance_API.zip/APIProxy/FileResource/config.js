context.setVariable("sapapim.clientId","client id");
context.setVariable("sapapim.secret","secret");