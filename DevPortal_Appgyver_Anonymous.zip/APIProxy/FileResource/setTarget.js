if (context.getVariable("MYPATH") && context.getVariable("MYURL")) {
var targetPath = context.getVariable("MYPATH");
var targetUrl = context.getVariable("MYURL");
print("retrieved variable: ", targetUrl, targetPath);
print("metadata request: ", targetPath.includes("metadata"));
if (targetPath.includes("metadata") === false) {
targetUrl = targetUrl.replace("/sapapimanagementguest", "");
var targetUri = targetUrl.concat(targetPath);
var targetHost = "https://<your BHE endpoint>.cfapps.us20.hana.ondemand.com";
var targetFinal = targetHost.concat(targetUri);
print("Final target URL: ", targetFinal);
context.targetRequest.url = targetFinal;
}
}