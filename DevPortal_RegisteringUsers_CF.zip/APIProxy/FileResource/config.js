context.setVariable("sapapim.clientId","client_id");
context.setVariable("sapapim.secret","client_secret");