var payload = JSON.parse(context.getVariable("request.content"));
var rolesAccessArr = [];
rolesAccessArr.push(payload["rolesAccess"])
payload["rolesAccess"] = rolesAccessArr;
context.setVariable("request.content",JSON.stringify(payload));