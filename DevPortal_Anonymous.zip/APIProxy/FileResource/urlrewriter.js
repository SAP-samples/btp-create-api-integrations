var rpUrl = context.proxyRequest.url;
print("got url");
print("last index of / ", rpUrl.lastIndexOf("/"));
var newPath = rpUrl.substring(rpUrl.lastIndexOf("/")+1, 1000);
if (newPath !== 'data.svc') {
print("newPath: ", newPath);
var basePath = rpUrl.substring(0, rpUrl.lastIndexOf("/"));
print("basePath: ", basePath);
var newPathSuffix = "/APIMgmt.";
var combinedPathSuffix = newPathSuffix.concat(newPath);
print("suffix: ", combinedPathSuffix);
var combinedPath = basePath + combinedPathSuffix;
print(combinedPath);
context.setVariable("MYPATH", combinedPathSuffix);
context.setVariable("MYURL", basePath);
}